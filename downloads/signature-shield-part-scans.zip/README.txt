Signature Shield — Signature Shield Part Scans
The scan modules — all six Signature scan types (quick, full, custom, USB, startup, memory) plus defense heuristics and the monitor.

PART 4 OF 5. This is one module of the whole Shield; the parts assemble into
the working tool on YOUR pc — nothing runs anywhere else.

FREE FOREVER: no accounts, no payments, no upsells, no trial traps.

ASSEMBLE (download the parts -> the installer compiles them -> protection RUNNING):
  1. Download all 5 part zips into ONE folder (or just the ones you need to
     refresh — the installer tells you if a part is missing).
  2. Unzip the installer part anywhere, then run:
       python3 install.py --assemble <the-folder-with-the-parts> [--edition ai-defense]
     The installer validates every part, compiles the modules, and installs
     the working tool. It shows every step and asks before touching your
     system scheduler. Nothing changes silently.
  3. Look for: PROTECTION: RUNNING

Or skip the parts and grab one full bundle instead (same tool, one download).
To remove cleanly later: python3 install.py --uninstall

Your system stays yours.
