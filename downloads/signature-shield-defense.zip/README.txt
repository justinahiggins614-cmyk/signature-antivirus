Signature Shield — Signature Shield Defense
Signature Shield Defense-Grade (classic) — the full arsenal, no AI.

FREE FOREVER: no accounts, no payments, no upsells, no trial traps.
To remove cleanly later: python3 install.py --uninstall

INSTALL (download -> run -> protection RUNNING):
  1. Unzip this file anywhere.
  2. python3 install.py --edition defense
     (The installer shows every step and asks before touching
      your system scheduler. Nothing changes silently.)
  3. Look for: PROTECTION: RUNNING

THEN:
  Check status anytime:            python3 shield_status.py
  Fail-safe rewind:  every AI action is journaled — say "undo" in chat.
  Off switch:  python3 install.py --off   /   --on to resume.
  Clean removal: python3 install.py --uninstall  (proves zero residue)

Your system stays yours.
